﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        txtname = New TextBox()
        txtsem = New TextBox()
        txtmat = New TextBox()
        txtadd = New TextBox()
        txtemail = New TextBox()
        txtfav = New TextBox()
        Button1 = New Button()
        Button2 = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.Font = New Font("Segoe UI Historic", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(315, 37)
        Label1.Name = "Label1"
        Label1.Size = New Size(240, 36)
        Label1.TabIndex = 0
        Label1.Text = "Student Infomation"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(149, 122)
        Label2.Name = "Label2"
        Label2.Size = New Size(132, 20)
        Label2.TabIndex = 1
        Label2.Text = "Name                    :"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(149, 165)
        Label3.Name = "Label3"
        Label3.Size = New Size(133, 20)
        Label3.TabIndex = 2
        Label3.Text = "Semester               :"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(149, 214)
        Label4.Name = "Label4"
        Label4.Size = New Size(132, 20)
        Label4.TabIndex = 3
        Label4.Text = "Matrix Number     :"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(149, 252)
        Label5.Name = "Label5"
        Label5.Size = New Size(133, 20)
        Label5.TabIndex = 4
        Label5.Text = "Address                 :"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(149, 347)
        Label6.Name = "Label6"
        Label6.Size = New Size(133, 20)
        Label6.TabIndex = 5
        Label6.Text = "Email                     :"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(148, 395)
        Label7.Name = "Label7"
        Label7.Size = New Size(133, 20)
        Label7.TabIndex = 6
        Label7.Text = "Fav.Subject            :"
        ' 
        ' txtname
        ' 
        txtname.Location = New Point(293, 119)
        txtname.Name = "txtname"
        txtname.Size = New Size(273, 27)
        txtname.TabIndex = 7
        ' 
        ' txtsem
        ' 
        txtsem.Location = New Point(293, 165)
        txtsem.Name = "txtsem"
        txtsem.Size = New Size(273, 27)
        txtsem.TabIndex = 8
        ' 
        ' txtmat
        ' 
        txtmat.Location = New Point(293, 214)
        txtmat.Name = "txtmat"
        txtmat.Size = New Size(273, 27)
        txtmat.TabIndex = 9
        ' 
        ' txtadd
        ' 
        txtadd.Location = New Point(293, 252)
        txtadd.Multiline = True
        txtadd.Name = "txtadd"
        txtadd.Size = New Size(273, 72)
        txtadd.TabIndex = 10
        ' 
        ' txtemail
        ' 
        txtemail.Location = New Point(293, 344)
        txtemail.Name = "txtemail"
        txtemail.Size = New Size(273, 27)
        txtemail.TabIndex = 11
        ' 
        ' txtfav
        ' 
        txtfav.Location = New Point(293, 392)
        txtfav.Name = "txtfav"
        txtfav.Size = New Size(273, 27)
        txtfav.TabIndex = 12
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(263, 469)
        Button1.Name = "Button1"
        Button1.Size = New Size(94, 29)
        Button1.TabIndex = 13
        Button1.Text = "Save"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Button2
        ' 
        Button2.Location = New Point(461, 469)
        Button2.Name = "Button2"
        Button2.Size = New Size(94, 29)
        Button2.TabIndex = 14
        Button2.Text = "Exit"
        Button2.UseVisualStyleBackColor = True
        ' 
        ' Form2
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources._5515426
        ClientSize = New Size(845, 523)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(txtfav)
        Controls.Add(txtemail)
        Controls.Add(txtadd)
        Controls.Add(txtmat)
        Controls.Add(txtsem)
        Controls.Add(txtname)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form2"
        Text = "Form2"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents txtsem As TextBox
    Friend WithEvents txtmat As TextBox
    Friend WithEvents txtadd As TextBox
    Friend WithEvents txtemail As TextBox
    Friend WithEvents txtfav As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
