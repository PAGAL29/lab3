﻿Public Class Form2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim studentName As String = txtname.Text
        Dim studentSemester As String = txtsem.Text
        Dim matriksNumber As String = txtmat.Text
        Dim studentAddress As String = txtadd.Text
        Dim studentEmail As String = txtemail.Text
        Dim academicInterest As String = txtfav.Text

        Dim message As String = $"Student Information Saved Successfully. " & vbCrLf &
                            "Name: " & studentName & vbCrLf &
                            "Semester: " & studentSemester & vbCrLf &
                            "Matrix Number: " & matriksNumber & vbCrLf &
                            "Address: " & studentAddress & vbCrLf &
                            "Email: " & studentEmail & vbCrLf &
                            "Academic Interest: " & academicInterest


        MsgBox(message, MsgBoxStyle.OkOnly, "Student Information")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class