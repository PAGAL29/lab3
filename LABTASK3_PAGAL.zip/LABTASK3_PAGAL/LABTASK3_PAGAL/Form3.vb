﻿Public Class Form3
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim studentName As String = txtname.Text
        Dim studentSemester As String = txtsem.Text
        Dim studentSubject As String = txtsub.Text
        Dim studentGrade As String = txtGrade.Text

        Dim rowIndex As Integer = DataGridView1.Rows.Add()
        DataGridView1.Rows(rowIndex).Cells(0).Value = studentName
        DataGridView1.Rows(rowIndex).Cells(1).Value = studentSemester
        DataGridView1.Rows(rowIndex).Cells(2).Value = studentSubject
        DataGridView1.Rows(rowIndex).Cells(3).Value = studentGrade
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class