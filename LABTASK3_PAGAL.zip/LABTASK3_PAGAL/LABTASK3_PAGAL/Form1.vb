﻿Public Class Form1



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim username As String = txtUsername.Text
        Dim pwd As String = txtPassword.Text





        If username = "student" And pwd = "student" Then
            MsgBox("Login Successfully", MsgBoxStyle.OkOnly, "Student Login")
            Form2.Show()
            Me.Hide()

        ElseIf username = "admin" And pwd = "admin" Then
            MsgBox("Login Successfully", MsgBoxStyle.OkOnly, "Admin Login")
            Form3.Show()
            Me.Hide()

        Else
            MsgBox("Incorrect Username or Password", MsgBoxStyle.OkOnly, "Invalid Login attempt")

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtPassword.UseSystemPasswordChar = True
    End Sub
End Class
